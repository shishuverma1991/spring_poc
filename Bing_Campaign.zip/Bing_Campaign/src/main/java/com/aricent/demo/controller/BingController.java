/*
 * Copyright (c) 2018.
 *
 */

package com.aricent.demo.controller;

import com.aricent.demo.service.BingCampaignManagementService;
import com.aricent.demo.service.BingService;
import com.microsoft.bingads.ApiEnvironment;
import com.microsoft.bingads.AuthorizationData;
import com.microsoft.bingads.OAuthTokens;
import com.microsoft.bingads.ServiceClient;
import com.microsoft.bingads.v12.bulk.*;
import com.microsoft.bingads.v12.bulk.entities.*;
import com.microsoft.bingads.v12.campaignmanagement.AdApiFaultDetail_Exception;
import com.microsoft.bingads.v12.campaignmanagement.ApiFaultDetail_Exception;
import com.microsoft.bingads.v12.campaignmanagement.*;
import com.microsoft.bingads.v12.campaignmanagement.ObjectFactory;
import com.microsoft.bingads.v12.reporting.*;
import com.microsoft.bingads.v12.reporting.ArrayOflong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping(value = "/bing")
public class BingController {

    @Autowired
    private BingService bingService;

    private static ObjectFactory objectFact = new ObjectFactory();


    @Autowired
    private BingCampaignManagementService bingCampaignManagementService;

    @GetMapping(value = "/bingadsuser/loginurl")
    public ResponseEntity<URL> getLoginUrl() {
        return new ResponseEntity<URL>(bingService.authenticateWithOauth(), HttpStatus.OK);
    }


    @GetMapping(value = "/bingadsuser/testAWS")
    public void testAWSS3() {
        try {
            File file = new File("D://4_Project_For_Reference//Sizmek_PoC//Bing_Campaign/test.csv");
            InputStream inputStream = Files.newInputStream(file.toPath());
            bingService.pushToS3Bucket(file.toPath(),inputStream);
        } catch (Exception exception) {
            exception.getStackTrace();
        }

    }


    @GetMapping(value = "/bingadsuser/exchangecode")
    public ResponseEntity<OAuthTokens> getTokens(@RequestParam("code") String code) {
        OAuthTokens oAuthTokens = bingService.exchangeCodeForTokens(code);
        return new ResponseEntity<OAuthTokens>(oAuthTokens, HttpStatus.OK);
    }

    @GetMapping(value = "/hello", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getHelloUrl() {
        return new ResponseEntity<String>("Hello", HttpStatus.OK);
    }

    @GetMapping(value = "/logout", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getLogoutUrl() {
        return new ResponseEntity<String>("LogOut", HttpStatus.OK);
    }


    @PostMapping(value = "/submit/campaign", consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getAddCampaign(@RequestBody ArrayOfCampaign campaigns) {
        bingCampaignManagementService.addCampaigns();
        return new ResponseEntity<String>("Hello", HttpStatus.OK);
    }

    @RequestMapping(value = "/search-connect/microsoft/simple", method = RequestMethod.GET)
    public List<Campaign> getAllCampaignTest(@RequestParam(value = "acId") String acId, @RequestParam(value = "refreshToken") String refreshToken) throws MalformedURLException, IOException, InterruptedException, ExecutionException, ApiFaultDetail_Exception, AdApiFaultDetail_Exception {
        ServiceClient<ICampaignManagementService> campaignService = getCampaignsService(acId, refreshToken);
        GetCampaignsByAccountIdRequest parameters = new GetCampaignsByAccountIdRequest();
        ArrayList<CampaignType> campaignType = new ArrayList<>();
        campaignType.add(CampaignType.SEARCH);
        campaignType.add(CampaignType.DYNAMIC_SEARCH_ADS);
        campaignType.add(CampaignType.AUDIENCE);
        campaignType.add(CampaignType.SHOPPING);

        parameters.setCampaignType(campaignType);
        parameters.setAccountId(Long.valueOf(acId));
        GetCampaignsByAccountIdResponse response = null;
        response = ((ICampaignManagementService) campaignService.getService()).getCampaignsByAccountId(parameters);
        return response.getCampaigns().getCampaigns();

    }


    private ServiceClient<ICampaignManagementService> getCampaignsService(String acId, String refreshToken) throws IOException {
        AuthorizationData authorizationData = bingService.getAuthorizationData(acId, refreshToken);
        authorizationData.setAccountId(Long.valueOf(acId));
        ServiceClient<ICampaignManagementService> campaignService = new ServiceClient<ICampaignManagementService>(authorizationData, ICampaignManagementService.class);
        return campaignService;
    }


    @RequestMapping(value = "/search-connect/microsoft/bulk", method = RequestMethod.GET)
    public List<Campaign> getAllCampaignssd(@RequestParam(value = "millisec") Long millisec, @RequestParam(value = "acId") String acId, @RequestParam(value = "refreshToken") String refreshToken) throws MalformedURLException, IOException, InterruptedException, ExecutionException {
        DownloadParameters downloadParameters = getDownloadParameters(DownloadEntity.CAMPAIGNS,millisec);
        BulkServiceManager bulkServiceManager = getBulkServiceManager(acId, refreshToken);
        BulkEntityIterable bulkEntityIterable = bulkServiceManager.downloadEntitiesAsync(downloadParameters, null).get();
        Iterator<BulkEntity> iterator = bulkEntityIterable.iterator();
        List<Campaign> campaigns = new ArrayList<Campaign>();

        iterator.forEachRemaining(bulkEntity -> {
            if (bulkEntity instanceof BulkCampaign) {
                Campaign campaign = ((BulkCampaign) bulkEntity).getCampaign();
                campaigns.add(campaign);
            }
        });
        bulkServiceManager.cleanupTempFiles();
        return campaigns;

    }


    @RequestMapping(value = "/search-connect/microsoft/keyword", method = RequestMethod.GET)
    public List<BulkKeyword> getAllKeyword(@RequestParam(value = "millisec") Long millisec,@RequestParam(value = "acId") String acId, @RequestParam(value = "refreshToken") String refreshToken) throws MalformedURLException, IOException, InterruptedException, ExecutionException {
        DownloadParameters downloadParameters = getDownloadParameters(DownloadEntity.KEYWORDS,millisec);
        BulkServiceManager bulkServiceManager = getBulkServiceManager(acId, refreshToken);
        BulkEntityIterable bulkEntityIterable = bulkServiceManager.downloadEntitiesAsync(downloadParameters, null).get();
        Iterator<BulkEntity> iterator = bulkEntityIterable.iterator();
        List<BulkKeyword> keywords = new ArrayList<BulkKeyword>();

        iterator.forEachRemaining(bulkEntity -> {
            if (bulkEntity instanceof BulkKeyword) {
                com.microsoft.bingads.v12.bulk.entities.BulkKeyword keyword = (com.microsoft.bingads.v12.bulk.entities.BulkKeyword) bulkEntity;
                keywords.add(keyword);
            }
        });
        bulkServiceManager.cleanupTempFiles();

        return keywords;

    }


    @RequestMapping(value = "/search-connect/microsoft/adgroup", method = RequestMethod.GET)
    public List<BulkAdGroup> getAllAdGroup(@RequestParam(value = "millisec") Long millisec,@RequestParam(value = "acId") String acId, @RequestParam(value = "refreshToken") String refreshToken) throws MalformedURLException, IOException, InterruptedException, ExecutionException {
        DownloadParameters downloadParameters = getDownloadParameters(DownloadEntity.AD_GROUPS,millisec);
        BulkServiceManager bulkServiceManager = getBulkServiceManager(acId, refreshToken);
        BulkEntityIterable bulkEntityIterable = bulkServiceManager.downloadEntitiesAsync(downloadParameters, null).get();
        Iterator<BulkEntity> iterator = bulkEntityIterable.iterator();
        List<BulkAdGroup> keywords = new ArrayList<BulkAdGroup>();

        iterator.forEachRemaining(bulkEntity -> {
            if (bulkEntity instanceof BulkAdGroup) {
                com.microsoft.bingads.v12.bulk.entities.BulkAdGroup keyword = (com.microsoft.bingads.v12.bulk.entities.BulkAdGroup) bulkEntity;
                keywords.add(keyword);
            }
        });
        bulkServiceManager.cleanupTempFiles();

        return keywords;

    }

    @RequestMapping(value = "/search-connect/microsoft/ads", method = RequestMethod.GET)
    public List<String> getAllAds(@RequestParam(value = "millisec") Long millisec,@RequestParam(value = "acId") String acId, @RequestParam(value = "refreshToken") String refreshToken) throws MalformedURLException, IOException, InterruptedException, ExecutionException {
        DownloadParameters downloadParameters = getDownloadParameters(DownloadEntity.ADS,millisec);
        BulkServiceManager bulkServiceManager = getBulkServiceManager(acId, refreshToken);
        BulkEntityIterable bulkEntityIterable = bulkServiceManager.downloadEntitiesAsync(downloadParameters, null).get();
        Iterator<BulkEntity> iterator = bulkEntityIterable.iterator();
        List<String> keywords = new ArrayList<>();
        iterator.forEachRemaining(bulkEntity -> {
            if (bulkEntity instanceof BulkExpandedTextAd) {
                BulkExpandedTextAd ad = (BulkExpandedTextAd) bulkEntity;
                keywords.add(ad.getAd().getText() +"..."+ad.getAd().getStatus());
            }
        });
        bulkServiceManager.cleanupTempFiles();
        return keywords;

    }


    @RequestMapping(value = "/search-connect/microsoft/upload/campaign", method = RequestMethod.GET)
    public List<Campaign> uploadCampaignTrackingUrl(@RequestParam(value = "acId") String acId, @RequestParam(value = "campaigId") String campaigId, @RequestParam(value = "refreshToken") String refreshToken) throws MalformedURLException, IOException, InterruptedException, ExecutionException {
        EntityUploadParameters uploadParameters = getUploadParameters(acId, campaigId);
        BulkServiceManager bulkServiceManager = getBulkServiceManager(acId, refreshToken);
        BulkEntityIterable bulkEntities = bulkServiceManager.uploadEntitiesAsync(uploadParameters, null).get();

        Iterator<BulkEntity> iterator = bulkEntities.iterator();

        List<Campaign> campaigns = new ArrayList<Campaign>();

        iterator.forEachRemaining(bulkEntity -> {
            if (bulkEntity instanceof BulkCampaign) {
                Campaign campaign = ((BulkCampaign) bulkEntity).getCampaign();
                campaigns.add(campaign);
            }
        });
        bulkServiceManager.cleanupTempFiles();

        return campaigns;

    }


    @RequestMapping(value = "/search-connect/microsoft/report", method = RequestMethod.GET)
    public void uploadCampaignReportTrackingUrl(@RequestParam(value = "acId") String acId, @RequestParam(value = "refreshToken") String refreshToken, @RequestParam(value = "campaignID") String campaignID) throws MalformedURLException, IOException, InterruptedException, ExecutionException {

        List<Long> listOfCampaigns = new ArrayList<>();
        listOfCampaigns.add(Long.valueOf(campaignID));
        AuthorizationData authorizationData = bingService.getAuthorizationData(acId, refreshToken);
        authorizationData.setAccountId(Long.valueOf(acId));
        KeywordPerformanceReportRequest keywordPerformanceReportRequest = new KeywordPerformanceReportRequest();


        keywordPerformanceReportRequest.setAggregation(ReportAggregation.DAILY);
        keywordPerformanceReportRequest.setFilter(getFilterForRequest());
        keywordPerformanceReportRequest.setColumns(getArrayOfCollumns());
        keywordPerformanceReportRequest.setScope(getScopeOfReport(Long.valueOf(acId), listOfCampaigns));
        keywordPerformanceReportRequest.setTime(getReportTime(LocalDate.now().minusDays(3), "Jerusalem"));
        keywordPerformanceReportRequest.setFormat(ReportFormat.CSV);
        keywordPerformanceReportRequest.setExcludeReportFooter(true);
        keywordPerformanceReportRequest.setExcludeReportHeader(true);
        keywordPerformanceReportRequest.setExcludeColumnHeaders(false);
        keywordPerformanceReportRequest.setReportName("CAMPAIGN_PERFORMANCE_REPORT_" + LocalDate.now());
        keywordPerformanceReportRequest.setReturnOnlyCompleteData(false);
        keywordPerformanceReportRequest.setSort(getSortOrder(KeywordPerformanceReportColumn.CAMPAIGN_ID, SortOrder.ASCENDING));


        ReportingServiceManager reportRequest = getReportRequest(authorizationData);
        ReportingDownloadParameters reportingDownloadParameters = new ReportingDownloadParameters();
        reportingDownloadParameters.setOverwriteResultFile(true);
        reportingDownloadParameters.setReportRequest(keywordPerformanceReportRequest);
        File file = reportRequest.downloadFileAsync(reportingDownloadParameters, null).get();
        System.out.println(file.getAbsolutePath());


    }

    private ReportingServiceManager getReportRequest(AuthorizationData authorizationData) throws MalformedURLException, IOException {
        ReportingServiceManager reportingServiceManager = new ReportingServiceManager(authorizationData, authorizationData.getAuthentication().getEnvironment());

        return reportingServiceManager;
    }


    private ArrayOfKeywordPerformanceReportSort getSortOrder(KeywordPerformanceReportColumn column, SortOrder order) {
        ArrayOfKeywordPerformanceReportSort array = new ArrayOfKeywordPerformanceReportSort();
        KeywordPerformanceReportSort sort = new KeywordPerformanceReportSort();
        sort.setSortColumn(column);
        sort.setSortOrder(order);
        array.getKeywordPerformanceReportSorts().add(sort);
        return array;
    }

    private KeywordPerformanceReportFilter getFilterForRequest() {
        KeywordPerformanceReportFilter filetr = new KeywordPerformanceReportFilter();
        Collection<KeywordStatusReportFilter> status = new ArrayList<>();
        status.add(KeywordStatusReportFilter.ACTIVE);
        filetr.setKeywordStatus(status);

        return filetr;
    }

    private ReportTime getReportTime(LocalDate localdate, String loc) {
        ReportTime reportTime = new ReportTime();
        com.microsoft.bingads.v12.reporting.Date date = new com.microsoft.bingads.v12.reporting.Date();
        date.setDay(localdate.getDayOfMonth());
        date.setMonth(localdate.getMonthValue());
        date.setYear(localdate.getYear());
        reportTime.setCustomDateRangeStart(date);


        LocalDate localDate2 = localdate.plusDays(2);
        com.microsoft.bingads.v12.reporting.Date date2 = new com.microsoft.bingads.v12.reporting.Date();
        date2.setDay(localDate2.getDayOfMonth());
        date2.setMonth(localDate2.getMonthValue());
        date2.setYear(localDate2.getYear());
        reportTime.setCustomDateRangeEnd(date2);
        reportTime.setReportTimeZone(ReportTimeZone.fromValue(loc));
        return reportTime;
    }

    private AccountThroughAdGroupReportScope getScopeOfReport(Long accountId, List<Long> listOfCampaigns) {
        List<CampaignReportScope> arrayOfCapaigns = getArrayOfCampaigns(accountId, listOfCampaigns);

        AccountThroughAdGroupReportScope scope = new AccountThroughAdGroupReportScope();
        ArrayOfCampaignReportScope arrayOfCampaignReportScope = new ArrayOfCampaignReportScope();
        arrayOfCampaignReportScope.getCampaignReportScopes().addAll(arrayOfCapaigns);
        scope.setCampaigns(arrayOfCampaignReportScope);
        ArrayOflong arrayOflong = new ArrayOflong();
        arrayOflong.getLongs().add(accountId);
        scope.setAccountIds(arrayOflong);
        return scope;
    }


    private List<CampaignReportScope> getArrayOfCampaigns(Long accountId, List<Long> listOfCampaigns) {
        List<CampaignReportScope> scopeCampaigns = new ArrayList<>();
        for (Long id : listOfCampaigns) {
            CampaignReportScope campaign = new CampaignReportScope();
            campaign.setAccountId(accountId);
            campaign.setCampaignId(id);
            scopeCampaigns.add(campaign);
        }
        return scopeCampaigns;
    }

    private ArrayOfKeywordPerformanceReportColumn getArrayOfCollumns() {
        ArrayOfKeywordPerformanceReportColumn column = new ArrayOfKeywordPerformanceReportColumn();
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.TIME_PERIOD);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.CAMPAIGN_ID);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.AD_GROUP_ID);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.KEYWORD_ID);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.CLICKS);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.IMPRESSIONS);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.AVERAGE_POSITION);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.SPEND);
        column.getKeywordPerformanceReportColumns().add(KeywordPerformanceReportColumn.CURRENCY_CODE);
        return column;
    }

    private EntityUploadParameters getUploadParameters(String acId, String campaigId) {
        EntityUploadParameters entityUploadParameters = new EntityUploadParameters();

        BulkCampaign bulkCampaign = new BulkCampaign();
        bulkCampaign.setAccountId(Long.valueOf(acId));
        Campaign campaign = new Campaign();
        campaign.setId(Long.valueOf(campaigId));
        campaign.setTrackingUrlTemplate("https://bs.serving-sys-int.com/Serving/?cn=search&c=1&mmdebug=666&t=1&sedid=bingads_100000000_{CampaignId}_{AdGroupId}_{TargetId}&gclid={msclkid}&MatchType={MatchType}&SEAdID={AdId}&scid=10000&advid=11111&rtu={escapedlpurl}");
        bulkCampaign.setCampaign(campaign);

        List<BulkEntity> bulkCampaigns = new ArrayList<>();
        bulkCampaigns.add(bulkCampaign);

        entityUploadParameters.setEntities(bulkCampaigns);

        entityUploadParameters.setResponseMode(ResponseMode.ERRORS_AND_RESULTS);
        return entityUploadParameters;
    }


    private BulkServiceManager getBulkServiceManager(String acId, String refreshToken) throws MalformedURLException, IOException {
        AuthorizationData authorizationData = bingService.getAuthorizationData(acId, refreshToken);
        authorizationData.setAccountId(Long.valueOf(acId));
        BulkServiceManager bulkServiceManager = new BulkServiceManager(authorizationData, ApiEnvironment.PRODUCTION);
        return bulkServiceManager;
    }

    private DownloadParameters getDownloadParameters(DownloadEntity downloadEntity,long milli) {
        DownloadParameters downloadParameters = new DownloadParameters();

        ArrayOfDownloadEntity entities = new ArrayOfDownloadEntity();
        entities.getDownloadEntities().add(downloadEntity);
        downloadParameters.setDownloadEntities(entities);
        downloadParameters.setFileType(DownloadFileType.CSV);
        Instant lastUpdatedAt = Instant.now().minusMillis(milli);

        if (lastUpdatedAt == null || lastUpdatedAt == Instant.EPOCH) {
            downloadParameters.setLastSyncTimeInUTC(null);//fetch all campaigns
        } else {
            java.util.Date date = java.util.Date.from(lastUpdatedAt);
            TimeZone timeZone = TimeZone.getTimeZone("UTC");
            Calendar cal = Calendar.getInstance(timeZone);
            cal.setTime(date);
            downloadParameters.setLastSyncTimeInUTC(cal);//fetch campaigns after lastSync time
        }
        return downloadParameters;
    }


}
