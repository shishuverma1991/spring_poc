package com.aricent.demo;

import com.aricent.demo.service.KeywordData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.microsoft.bingads.ServiceClient;
import com.microsoft.bingads.v12.reporting.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import javax.validation.constraints.NotNull;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MyJob {
    private static final String CSV_DELIMITER = ",";

    private enum Header {

        TimePeriod,CampaignId,AdGroupId,KeywordId,
        Clicks,Impressions,AveragePosition,Spend,
        CurrencyCode;



        public static String[] getHeaderList(Class<? extends Enum<?>> e) {

            return Arrays.stream(e.getEnumConstants()).map(Enum::name).toArray(String[]::new);
        }
    };

    public static void main(String[] args) throws IOException {
        File f = new File("D://4_Project_For_Reference//Sizmek_PoC//Bing_Campaign/test.csv");

        /*Map<String, List<KeywordData>> stringListMap = readFile(f);

        for (List<KeywordData> data : stringListMap.values()) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
            try {
                mapper.writeValue(System.out, data);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }*/



      Map<String, List<KeywordData>> stringListMap= testApache(f);

        for (List<KeywordData> data : stringListMap.values()) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
           /* try {*/
                //mapper.writeValue(System.out, data);

                divideAndProcessList(data,5);

            /*} catch (IOException e) {
                e.printStackTrace();
            }*/
        }






    }

    private static void divideAndProcessList(List data, int batchSize) {
        int indexPointer=0;
        int iterations=0;
        while(batchSize>0 && batchSize<data.size() && iterations<(data.size()/batchSize)){
           //List<KeywordData> keywordData = data.subList(indexPointer, (indexPointer+(batchSize-1)));
            System.out.println(indexPointer +"-----"+(indexPointer+(batchSize-1)));
           // processDataInBatch(keywordData);
            indexPointer=indexPointer+batchSize;
            iterations++;
        }
        System.out.println(indexPointer +"-----"+(data.size()));
       // List<KeywordData> keywordData = data.subList(indexPointer, (data.size()));
        //processDataInBatch(keywordData);
    }

    private static void processDataInBatch(List<KeywordData> keywordData) {
        keywordData.stream().forEach(ele->System.out.println(ele.getKeywordId()));
    }

    public static Map<String, List<KeywordData>> testApache(File file) throws IOException {
        BufferedReader reader = Files.newBufferedReader(Paths.get(file.getName()), Charset.defaultCharset());
        CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader(Header.getHeaderList(Header.class)).withIgnoreHeaderCase().withTrim());
        final Map<String, List<KeywordData>> collect=csvParser.getRecords().stream().skip(1).filter(applyFilterONCSVRecord()).map(csvRecord -> {
            try {
                KeywordData data = new KeywordData(
                        csvRecord.get(Header.TimePeriod.name()),
                        csvRecord.get(Header.CampaignId.name()),
                        csvRecord.get(Header.AdGroupId.name()),
                        csvRecord.get(Header.KeywordId.name()),
                        csvRecord.get(Header.Clicks.name()),
                        csvRecord.get(Header.Impressions.name()),
                        csvRecord.get(Header.AveragePosition.name()),
                        csvRecord.get(Header.Spend.name()),
                        csvRecord.get(Header.CurrencyCode.name()));
                return data;
            } catch (IndexOutOfBoundsException ex) {
                System.out.println("Data not complete for the entry.");
            }
            return null;
        }).filter(ele -> ele != null).collect(Collectors.groupingBy(KeywordData::getCampaignId));
        return collect;

    }


    public static Predicate<CSVRecord> applyFilterONCSVRecord() {
        final Predicate<CSVRecord> result = csvRecord ->
                Long.valueOf(!csvRecord.get(Header.Impressions.name()).isEmpty() ? csvRecord.get(Header.Impressions.name()) : "0") > 0;
        return result;
    }


    public static Map<String, List<KeywordData>> readFile(File file) throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get(file.getName()), Charset.defaultCharset())) {
            final Map<String, List<KeywordData>> collect = lines.skip(1).filter(applyFilter()).map(line -> {
                String[] dArr = line.split(CSV_DELIMITER);
                try {

                    KeywordData data = new KeywordData(dArr[0], dArr[1], dArr[2], dArr[3], dArr[4], dArr[5], dArr[6], dArr[7], dArr[8]);
                    return data;
                } catch (IndexOutOfBoundsException ex) {
                    System.out.println("Data not complete for the entry.");
                }
                return null;
            }).filter(ele -> ele != null).collect(Collectors.groupingBy(KeywordData::getCampaignId));
            return collect;


        }
    }

    public static Predicate<String> applyFilter() {
        final Predicate<String> result = line ->
                Long.valueOf(!line.split(CSV_DELIMITER)[5].isEmpty() ? line.split(CSV_DELIMITER)[5] : "0") > 0;
        return result;
    }








}


class Example
{
    static class Example1{

        Example1(){

        }
    }
}
