/*
 * Copyright (c) 2018.
 *
 */

package com.aricent.demo.configuration;

import com.aricent.demo.model.BingEnvironment;
import com.microsoft.bingads.ApiEnvironment;
import com.microsoft.bingads.AuthorizationData;
import com.microsoft.bingads.OAuthWebAuthCodeGrant;
import com.microsoft.bingads.ServiceClient;
import com.microsoft.bingads.v12.campaignmanagement.ICampaignManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.net.URL;

import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
@ComponentScan({"com.aricent.demo"})
public class ConfigureApplication {

    private ServiceClient<ICampaignManagementService> campaignManagementServiceClient=null;
    private Environment environment=null;
    private AuthorizationData authorizationData=null;
    private ApiEnvironment apiEnvironment=null;

    private BingEnvironment bingLocalEnvironment=null;

    @Autowired
    public ConfigureApplication(Environment environment) {
        this.environment = environment;
    }

    @Bean
    @Scope(scopeName = "prototype")
    public ServiceClient<ICampaignManagementService> campaignManagementServiceClient() {

        try {
            apiEnvironment();
            authorizationData = authorizationData();
            OAuthWebAuthCodeGrant oAuthWebAuthCodeGrant = new OAuthWebAuthCodeGrant(bingLocalEnvironment.getClientId(), bingLocalEnvironment.getClientSecret(), new URL(bingLocalEnvironment.getRedirectUri()), ApiEnvironment.fromValue(bingLocalEnvironment.getBingEnvironmentType()));
            authorizationData.setAuthentication(oAuthWebAuthCodeGrant);
            campaignManagementServiceClient=new ServiceClient<ICampaignManagementService>(authorizationData, apiEnvironment, ICampaignManagementService.class);
        }catch(Exception ex){
            ex.printStackTrace();
        }

        return campaignManagementServiceClient;
    }
    @Bean
    public AuthorizationData authorizationData() throws Exception{
        authorizationData = new AuthorizationData();
        authorizationData.setDeveloperToken(bingLocalEnvironment.getDeveloperToken());
        return authorizationData;
    }


    @Bean
    public BingEnvironment bingLocalEnvironment() throws Exception {
        bingLocalEnvironment=new BingEnvironment(environment);
        return bingLocalEnvironment;
    }


    @Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select().apis(RequestHandlerSelectors.basePackage("com.aricent.demo.controller"))
                .paths(regex("/bing.*"))
                .build().apiInfo(metaData());

    }

    private ApiInfo metaData() {
        ApiInfo apiInfo = new ApiInfo(
                "Bing   API",
                "Bing  API for campaign management ",
                "1.0",
                "Terms of service",
                new Contact("Shishupal", "", "Shishupal@gmail.com"),
                "Apache License Version 2.0", "");
        return apiInfo;

    }


    private void apiEnvironment() throws Exception{
        apiEnvironment = ApiEnvironment.fromValue(bingLocalEnvironment().getBingEnvironmentType());
    }
}
