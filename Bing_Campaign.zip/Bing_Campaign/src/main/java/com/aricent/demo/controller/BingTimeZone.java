package com.aricent.demo.controller;

import java.time.ZoneId;
import java.time.ZoneOffset;

public class BingTimeZone {
    public final String value;
    public final String description;
    public final String offset;
    public final ZoneId zone;

    public BingTimeZone(String value, String description, String offset, double offsetNum) {
        this.value = value;
        this.description = description;
        this.offset = offset;
        this.zone = ZoneOffset.ofTotalSeconds((int) (offsetNum * 60 * 60));
    }

    public static final BingTimeZone[] timeZones = new BingTimeZone[]{
            new BingTimeZone("AbuDhabiMuscat", "Abu Dhabi and Muscat time zone.", "UTC+4", 4),
            new BingTimeZone("Adelaide", "Adelaide, Australia time zone.", "UTC+9.5", 9.5),
            new BingTimeZone("Alaska", "Alaska time zone.", "UTC-9", -9),
            new BingTimeZone("AlmatyNovosibirsk", "Almaty and Novosibirsk time zone.", "UTC+6", 6),
            new BingTimeZone("AmsterdamBerlinBernRomeStockholmVienna", "Amsterdam, Berlin, Bern, Rome, Stockholm, and Vienna time zone.", "UTC+1", 1),
            new BingTimeZone("Arizona", "Arizona time zone", "UTC-7", -7),
            new BingTimeZone("AstanaDhaka", "Astana and Dhaka time zone.", "UTC+6", 6),
            new BingTimeZone("AthensBuckarestIstanbul", "Athens, Istanbul, Beirut, and Minsk time zone.", "UTC+2", 2),
            new BingTimeZone("AtlanticTimeCanada", "Atlantic Time and Canada time zone.", "UTC-4", -4),
            new BingTimeZone("AucklandWellington", "Auckland and Wellington, new Zealand time zone.", "UTC+12", 12),
            new BingTimeZone("Azores", "Azores time zone.", "UTC-1", -1),
            new BingTimeZone("Baghdad", "Baghdad time zone.", "UTC+3", 3),
            new BingTimeZone("BakuTbilisiYerevan", "Baku, Tbilisi, and Yerevan time zone.", "UTC+4", 4),
            new BingTimeZone("BangkokHanoiJakarta", "Bangkok, Hanoi, and Jakarta time zone.", "UTC+7", 7),
            new BingTimeZone("BeijingChongqingHongKongUrumqi", "Beijing, Chongqing, Hong Kong, and Urumqi time zone.", "UTC+8", 8),
            new BingTimeZone("BelgradeBratislavaBudapestLjubljanaPrague", "Belgrade, Bratislava, Budapest, Ljubljana, and Prague time zone.", "UTC+1", 1),
            new BingTimeZone("BogotaLimaQuito", "Bogota, Lima, and Quito time zone.", "UTC-5", -5),
            new BingTimeZone("Brasilia", "Brasilia time zone.", "UTC-3", -3),
            new BingTimeZone("Brisbane", "Brisbane time zone.", "UTC+10", 10),
            new BingTimeZone("BrusselsCopenhagenMadridParis", "Brussels, Copenhagen, Madrid, and Paris time zone.", "UTC+1", 1),
            new BingTimeZone("Bucharest", "Bucharest time zone.", "UTC+2", 2),
            new BingTimeZone("BuenosAiresGeorgetown", "Buenos Aires and Georgetown time zone.", "UTC-3", -3),
            new BingTimeZone("Cairo", "Cairo time zone.", "UTC+2", 2),
            new BingTimeZone("CanberraMelbourneSydney", "Canberra, Melbourne, and Sydney time zone.", "UTC+10", 10),
            new BingTimeZone("CapeVerdeIsland", "Cape Verde Island time zone.", "UTC-1", -1),
            new BingTimeZone("CaracasLaPaz", "Caracas and La Paz (Bolivia) time zone.", "UTC-4", -4),
            new BingTimeZone("CasablancaMonrovia", "Casablanca and Monrovia time zone.", "UTC+0", 0),
            new BingTimeZone("CentralAmerica", "Central America time zone.", "UTC-6", -6),
            new BingTimeZone("CentralTimeUSCanada", "Central Time U.S. and Canada time zone.", "UTC-6", -6),
            new BingTimeZone("ChennaiKolkataMumbaiNewDelhi", "Chennai, Kolkata, Mumbai, and new Delhi time zone.", "UTC+5.5", 5.5),
            new BingTimeZone("ChihuahuaLaPazMazatlan", "Chihuahua, La Paz (Mexico), and Mazatlan time zone.", "UTC-7", -7),
            new BingTimeZone("Darwin", "Darwin time zone.", "UTC+9.5", 9.5),
            new BingTimeZone("EasternTimeUSCanada", "Eastern Time U.S. and Canada time zone.", "UTC-5", -5),
            new BingTimeZone("Ekaterinburg", "Ekaterinburg time zone.", "UTC+5", 5),
            new BingTimeZone("FijiKamchatkaMarshallIsland", "Fiji, Kamchatka, and Marshall Island time zone.", "UTC+12", 12),
            new BingTimeZone("Greenland", "Greenland time zone.", "UTC-3", -3),
            new BingTimeZone("GreenwichMeanTimeDublinEdinburghLisbonLondon", "Greenwich Mean Time, Dublin, Edinburgh, Lisbon, and London time zone.", "UTC+0", 0),
            new BingTimeZone("GuadalajaraMexicoCityMonterrey", "Guadalajara, Mexico City, and Monterrey time zone.", "UTC-6", -6),
            new BingTimeZone("GuamPortMoresby", "Guam and Port Moresby time zone.", "UTC+10", 10),
            new BingTimeZone("HararePretoria", "Harare and Pretoria time zone.", "UTC+2", 2),
            new BingTimeZone("Hawaii", "Hawaii time zone.", "UTC-10", -10),
            new BingTimeZone("HelsinkiKyivRigaSofiaTallinnVilnius", "Helsinki, Kyiv, Riga, Sofia, Tallinn, and Vilnius time zone.", "UTC+2", 2),
            new BingTimeZone("Hobart", "Hobart time zone.", "UTC+10", 10),
            new BingTimeZone("IndianaEast", "Indiana (East) time zone.", "UTC-5", -5),
            new BingTimeZone("InternationalDateLineWest", "International Date Line (West) time zone.", "UTC-12", -12),
            new BingTimeZone("IrkutskUlaanBataar", "Irkutsk and Ulaanbaatar time zone.", "UTC+8", 8),
            new BingTimeZone("IslandamabadKarachiTashkent", "Islamabad, Karachi, and Tashkent time zone.", "UTC+5", 5),
            new BingTimeZone("Jerusalem", "Jerusalem time zone.", "UTC+2", 2),
            new BingTimeZone("Kabul", "Kabul time zone.", "UTC+4.5", 4.5),
            new BingTimeZone("Kathmandu", "Kathmandu time zone.", "UTC+5.75", 5.75),
            new BingTimeZone("Krasnoyarsk", "Krasnoyarsk time zone.", "UTC+7", 7),
            new BingTimeZone("KualaLumpurSingapore", "Kuala Lumpur and Singapore time zone.", "UTC+8", 8),
            new BingTimeZone("KuwaitRiyadh", "Kuwait and Riyadh time zone.", "UTC+3", 3),
            new BingTimeZone("MidAtlantic", "Mid-Atlantic time zone.", "UTC-2", -2),
            new BingTimeZone("MidwayIslandAndSamoa", "Midway Island and Samoa time zone.", "UTC-11", -11),
            new BingTimeZone("MoscowStPetersburgVolgograd", "Moscow, St Petersburg, and Volgograd time zone.", "UTC+3", 3),
            new BingTimeZone("MountainTimeUSCanada", "Mountain Time U.S. and Canada time zone.", "UTC-7", -7),
            new BingTimeZone("Nairobi", "Nairobi time zone.", "UTC+3", 3),
            new BingTimeZone("Newfoundland", "Newfoundland time zone.", "UTC-3.5", -3.5),
            new BingTimeZone("Nukualofa", "Nuku'alofa time zone.", "UTC+13", 13),
            new BingTimeZone("OsakaSapporoTokyo", "Osaka, Sapporo, and Tokyo time zone.", "UTC+9", 9),
            new BingTimeZone("PacificTimeUSCanadaTijuana", "Pacific Time, U.S. and Canada, and Tijuana time zone.", "UTC-8", -8),
            new BingTimeZone("Perth", "Perth time zone.", "UTC+8", 8),
            new BingTimeZone("Rangoon", "Rangoon time zone.", "UTC+6.5", 6.5),
            new BingTimeZone("Santiago", "Santiago time zone.", "UTC-4", -4),
            new BingTimeZone("SarajevoSkopjeWarsawZagreb", "Sarajevo, Skopie, Warsaw, and Zagreb time zone.", "UTC+1", 1),
            new BingTimeZone("Saskatchewan", "Saskatchewan time zone.", "UTC-6", -6),
            new BingTimeZone("Seoul", "Seoul time zone.", "UTC+9", 9),
            new BingTimeZone("SolomonIslandNewCaledonia", "Magadan, Solomon Islands, and new Caledonia time zone.", "UTC+11", 11),
            new BingTimeZone("SriJayawardenepura", "Sri Jayawardenepura time zone.", "UTC+5.5", 5.5),
            new BingTimeZone("Taipei", "Taipei time zone.", "UTC+8", 8),
            new BingTimeZone("Tehran", "Tehran time zone.", "UTC+3.5", 3.5),
            new BingTimeZone("Vladivostok", "Vladivostok time zone.", "UTC+10", 10),
            new BingTimeZone("WestCentralAfrica", "West Central Africa time zone.", "UTC+1", 1),
            new BingTimeZone("Yakutsk", "Yakutsk time zone.", "UTC+9", 9)
    };

    public static ZoneId findTimeZone(String value) {
        for (BingTimeZone tz : BingTimeZone.timeZones) {
            if (tz.value.equals(value) || tz.offset.equals(value)) {
                return tz.zone;
            }
        }

        try {
            return ZoneId.of(value);
        } catch (Exception ignored) {
            return null;
        }
    }
}
