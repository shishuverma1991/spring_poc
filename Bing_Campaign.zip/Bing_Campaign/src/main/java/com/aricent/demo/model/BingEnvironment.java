package com.aricent.demo.model;


import lombok.Getter;
import lombok.Setter;
import org.springframework.core.env.Environment;


public class BingEnvironment {

    private Environment environment;

    public BingEnvironment(Environment environment){
        this.environment=environment;
        init();
    }

    @Getter
    @Setter
    private String bingEnvironmentType;

    @Getter
    @Setter
    private String developerToken;

    @Getter
    @Setter
    private String clientId;

    @Getter
    @Setter
    private String clientSecret;

    @Getter
    @Setter
    private String redirectUri;

    @Getter
    @Setter
    private String refreshTokenPath;


    @Getter
    @Setter
    private Long accountId;

    @Getter
    @Setter
    private String awsBucketName;

    @Getter
    @Setter
    private String awsSecretKey;

    @Getter
    @Setter
    private String awsAccessKey;

    @Getter
    @Setter
    private String awsRegion;


    private void init() {
        this.bingEnvironmentType = environment.getProperty("bing.environment", "Sandbox");
        this.developerToken = environment.getProperty("bing.developer.token", "BBD37VB98");
        this.clientId = environment.getProperty("bing.developer.client.Id", "e54e248f-18f3-4413-9194-748558d57e6a");
        this.clientSecret = environment.getProperty("bing.developer.client.Secret", "tedFAGKA?=mtcsIH50600-}");
        this.redirectUri = environment.getProperty("bing.developer.redirectUri", "http://localhost:8081/swagger-ui.html");
        this.refreshTokenPath = environment.getProperty("bing.developer.refreshtoken.path", "refresh.txt");
        this.accountId=Long.valueOf(environment.getProperty("bing.developer.account.id"));
        this.awsBucketName=environment.getProperty("aws.bucket.name");
        this.awsSecretKey=environment.getProperty("aws.secret.key");
        this.awsAccessKey=environment.getProperty("aws.account.key");
        this.awsRegion=environment.getProperty("aws.region");


    }
}
