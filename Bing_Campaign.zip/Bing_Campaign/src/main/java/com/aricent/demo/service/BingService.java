package com.aricent.demo.service;

import com.microsoft.bingads.AuthorizationData;
import com.microsoft.bingads.OAuthTokens;

import java.io.InputStream;
import java.net.URL;
import java.nio.file.Path;

public interface BingService {

     URL authenticateWithOauth();

     OAuthTokens exchangeCodeForTokens(String code);
     AuthorizationData getAuthorizationData(String acId, String refreshToken);

    void pushToS3Bucket(Path path, InputStream inputStream);
}
