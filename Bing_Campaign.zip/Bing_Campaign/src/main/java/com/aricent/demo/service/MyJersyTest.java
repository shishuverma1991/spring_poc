package com.aricent.demo.service;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriBuilder;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MyJersyTest {

    public static void main(String[] args){


        jerseyTest();



    }



    public  static void jerseyTest(){
        try {
            ClientConfig config = new DefaultClientConfig();
            Client client = Client.create(config);

            WebResource webResource = client.resource(UriBuilder.fromUri("https://int.eyeblaster.com/MediaMind.InternalAPI.SearchConnect.Web/SearchConnectSvc.svc/rest/searchconnect/migrateaccount/6039968032").build());
            MultivaluedMap map=new MultivaluedMapImpl();
            map.add("Content-Length","222");
            ClientResponse response = webResource.type(MediaType.APPLICATION_JSON).post(ClientResponse.class,map);

            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatus());
            }

            String output = response.getEntity(String.class);

            System.out.println("Output from Server .... \n");
            System.out.println(output);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public  static void apacheTest() throws IOException {
      /* HttpClient client = new DefaultHttpClient();
       HttpPost post = new HttpPost("https://int.eyeblaster.com/MediaMind.InternalAPI.SearchConnect.Web/SearchConnectSvc.svc/rest/searchconnect/migrateaccount/6039968032");
       //StringEntity input = new StringEntity('product');
       //post.setEntity(input);
       HttpResponse response = client.execute(post);
       BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
       String line = "";
       while ((line = rd.readLine()) != null) {
           System.out.println(line);
       }*/
    }

}