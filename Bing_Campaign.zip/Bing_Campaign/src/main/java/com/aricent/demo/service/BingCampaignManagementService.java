package com.aricent.demo.service;

import com.aricent.demo.model.BingEnvironment;
import com.microsoft.bingads.ServiceClient;
import com.microsoft.bingads.v12.campaignmanagement.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.rmi.RemoteException;

@Service
public class BingCampaignManagementService {



    @Autowired
    private ServiceClient<ICampaignManagementService> campaignManagementServiceClient;


   /* public AddCampaignsResponse addCampaigns(ArrayOfCampaign campaigns) throws RemoteException, Exception {

        AddCampaignsRequest request = new AddCampaignsRequest();
        request.setAccountId(150168863l);
        request.setCampaigns(campaigns);
        ICampaignManagementService service = (ICampaignManagementService) campaignManagementServiceClient.getService();
        return service.addCampaigns(request);
    }*/

    @Autowired
    private BingEnvironment bingLocalEnvironment;


    public void addCampaigns()  {
        AddCampaignsResponse addCampaignsResponse=null;
        try {
            GetCampaignSizesByAccountIdRequest request = new GetCampaignSizesByAccountIdRequest();
            request.setAccountId(bingLocalEnvironment.getAccountId());
            ArrayOflong arrayOflong = new ArrayOflong();
            request.setCampaignIds(arrayOflong);
            ICampaignManagementService service = campaignManagementServiceClient.getService();
            service.getCampaignSizesByAccountId(request);
            // addCampaignsResponse = service.addCampaigns(request);
        }catch (Exception ex){

            ex.printStackTrace();
        }
        //return addCampaignsResponse;
    }
}
