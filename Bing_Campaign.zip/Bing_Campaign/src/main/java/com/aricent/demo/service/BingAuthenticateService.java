package com.aricent.demo.service;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.aricent.demo.exception.BingAdsExceptionHelper;
import com.aricent.demo.model.BingEnvironment;
import com.microsoft.bingads.ApiEnvironment;
import com.microsoft.bingads.AuthorizationData;
import com.microsoft.bingads.OAuthTokens;
import com.microsoft.bingads.OAuthWebAuthCodeGrant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;

@Service
public class BingAuthenticateService implements BingService {

    @Autowired
    private BingEnvironment bingLocalEnvironment;

    @Autowired
    private AuthorizationData authorizationData;


    @Override
    public URL authenticateWithOauth() {
        URL url = null;
        try {
            OAuthWebAuthCodeGrant oAuthWebAuthCodeGrant = new OAuthWebAuthCodeGrant(bingLocalEnvironment.getClientId(), bingLocalEnvironment.getClientSecret(), new URL(bingLocalEnvironment.getRedirectUri()), ApiEnvironment.fromValue(bingLocalEnvironment.getBingEnvironmentType()));
            authorizationData.setAuthentication(oAuthWebAuthCodeGrant);
            url = ((OAuthWebAuthCodeGrant) (authorizationData.getAuthentication())).getAuthorizationEndpoint();
        } catch (Exception ex) {
            String faultXml = BingAdsExceptionHelper.getBingAdsExceptionFaultXml(ex, System.out);
            String message = BingAdsExceptionHelper.handleBingAdsSDKException(ex, System.out);
            ex.printStackTrace();
        } finally {
            return url;
        }
    }

    @Override
    public OAuthTokens exchangeCodeForTokens(String code) {
        OAuthTokens tokens = null;
        try {
            URL url = new URL(bingLocalEnvironment.getRedirectUri() + "?code=" + code);
            OAuthWebAuthCodeGrant oAuthWebAuthCodeGrant = new OAuthWebAuthCodeGrant(bingLocalEnvironment.getClientId(), bingLocalEnvironment.getClientSecret(), new URL(bingLocalEnvironment.getRedirectUri()), ApiEnvironment.fromValue(bingLocalEnvironment.getBingEnvironmentType()));
            authorizationData.setAuthentication(oAuthWebAuthCodeGrant);
            tokens = ((OAuthWebAuthCodeGrant) (authorizationData.getAuthentication())).requestAccessAndRefreshTokens(url);
            writeOAuthRefreshToken(tokens.getRefreshToken());

        } catch (Exception ex) {
            String faultXml = BingAdsExceptionHelper.getBingAdsExceptionFaultXml(ex, System.out);
            String message = BingAdsExceptionHelper.handleBingAdsSDKException(ex, System.out);
            ex.printStackTrace();
        }
        return tokens;
    }


    public AuthorizationData getAuthorizationData(String acId, String refreshToken) {

        try {
            authorizationData.setAuthentication(new OAuthWebAuthCodeGrant(bingLocalEnvironment.getClientId(), bingLocalEnvironment.getClientSecret(), new URL(bingLocalEnvironment.getRedirectUri()), refreshToken, ApiEnvironment.fromValue(bingLocalEnvironment.getBingEnvironmentType())));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return authorizationData;

    }

    @Override
    public void pushToS3Bucket(Path path, InputStream inputStream) {
        pushTOAmazonS3Client(path, inputStream);
    }


    private void pushTOAmazonS3Client(Path path, InputStream inputStream) {
        AWSCredentials awsCreds = new BasicAWSCredentials(bingLocalEnvironment.getAwsAccessKey(), bingLocalEnvironment.getAwsSecretKey());
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setMaxConnections(1);

        AmazonS3 s3Client = AmazonS3ClientBuilder.standard().
                withRegion(bingLocalEnvironment.getAwsRegion()).
                withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();

        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentType("application/json");
        metadata.addUserMetadata("x-amz-meta-title", "someTitle");
        PutObjectRequest putRequest = new PutObjectRequest(
                bingLocalEnvironment.getAwsBucketName(),
                path.toString(),
                inputStream,
                metadata);
        s3Client.putObject(putRequest);
    }

    private String readOAuthRefreshToken() throws IOException {
        String refreshToken = null;
        File file = new File(bingLocalEnvironment.getRefreshTokenPath());
        if (file.exists() && !file.isDirectory()) {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            refreshToken = bufferedReader.readLine();
        }
        return refreshToken;
    }

    private void writeOAuthRefreshToken(String refreshToken) throws IOException {
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(bingLocalEnvironment.getRefreshTokenPath()), "utf-8"))) {
            writer.write(refreshToken);
        }
    }

}
