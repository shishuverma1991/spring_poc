package com.aricent.demo.service;

import java.io.Serializable;

public class KeywordData implements Serializable {
    private final String timePeriod;
    private final String CampaignId;
    private final String adGroupId;
    private final String keywordId;
    private final String clicks;
    private final String impressions;
    private final String averagePosition;
    private final String spend;
    private final String currencyCode;

    public KeywordData(String timePeriod, String campaignId, String adGroupId, String keywordId, String clicks, String impressions, String averagePosition, String spend, String currencyCode) {
        this.timePeriod = timePeriod;
        this.CampaignId = campaignId;
        this.adGroupId = adGroupId;
        this.keywordId = keywordId;
        this.clicks = clicks;
        this.impressions = impressions;
        this.averagePosition = averagePosition;
        this.spend = spend;
        this.currencyCode = currencyCode;
    }

    public String getCampaignId() {
        return CampaignId;
    }

    public String getAdGroupId() {
        return adGroupId;
    }

    public String getKeywordId() {
        return keywordId;
    }

    public String getClicks() {
        return clicks;
    }

    public String getImpressions() {
        return impressions;
    }

    public String getAveragePosition() {
        return averagePosition;
    }

    public String getSpend() {
        return spend;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }
    public String getTimePeriod() {
        return timePeriod;
    }
}
