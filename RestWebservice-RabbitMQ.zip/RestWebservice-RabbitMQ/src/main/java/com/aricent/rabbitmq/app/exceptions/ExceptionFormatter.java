package com.aricent.rabbitmq.app.exceptions;

import java.util.Date;

import org.springframework.stereotype.Component;


public class ExceptionFormatter {
	
	private Date date;
	private String errorMsg;
	private String errorDetail;
	
	
	public ExceptionFormatter(Date date, String errorMsg, String errorDetail) {
		super();
		this.date = date;
		this.errorMsg = errorMsg;
		this.errorDetail = errorDetail;
	}


	public Date getDate() {
		return date;
	}


	public String getErrorMsg() {
		return errorMsg;
	}


	public String getErrorDetail() {
		return errorDetail;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}


	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}
	
	
	
}
