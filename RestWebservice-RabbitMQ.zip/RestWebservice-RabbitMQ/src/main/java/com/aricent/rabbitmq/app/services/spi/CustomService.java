package com.aricent.rabbitmq.app.services.spi;


public interface CustomService {

	
	public String produceMessage(String message);
}
