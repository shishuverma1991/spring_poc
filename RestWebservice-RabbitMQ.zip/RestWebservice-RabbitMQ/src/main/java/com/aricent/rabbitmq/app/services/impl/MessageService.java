package com.aricent.rabbitmq.app.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.aricent.rabbitmq.app.repositories.impl.MessageRepositoryImpl;
import com.aricent.rabbitmq.app.services.spi.CustomService;

@Service
public class MessageService implements CustomService {
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	
	@Autowired
	private MessageRepositoryImpl messageRepositoryImpl;
	
	
	@Value("${spring.rabbitmq.template.exchange}")
	private String exchange;
	
	@Value("${spring.rabbitmq.template.routing-key}")
	private String routingKey;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageService.class);
	
	@Override
	public String produceMessage(String msg){
		
		LOGGER.info("Execution started with value ----- SERVICE-------{}", msg);
		try {
		//rabbitTemplate.convertAndSend(exchange, routingKey, msg);
		messageRepositoryImpl.createMessageRepoResource(msg);
		}catch(AmqpException exception) {
			throw new AmqpException("Error in connecting to host.");
		}
		LOGGER.info("Execution Completed succesfully! -----SERVICE -------");
		return "Message Sent successfully!";
	}
	
}
