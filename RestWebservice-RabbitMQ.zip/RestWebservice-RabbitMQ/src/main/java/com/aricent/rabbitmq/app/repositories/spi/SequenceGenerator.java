package com.aricent.rabbitmq.app.repositories.spi;

public interface SequenceGenerator<T> {

	public long getNextSequence(Class<T> entityClass); 
}
