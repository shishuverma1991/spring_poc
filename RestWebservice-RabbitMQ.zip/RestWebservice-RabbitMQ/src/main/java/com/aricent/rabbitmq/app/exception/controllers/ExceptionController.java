package com.aricent.rabbitmq.app.exception.controllers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.aricent.rabbitmq.app.exceptions.ExceptionFormatter;

@ControllerAdvice
@RestController
public class ExceptionController extends ResponseEntityExceptionHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionController.class);
	
	@ExceptionHandler({AmqpException.class,Exception.class})
	public  final ResponseEntity<ExceptionFormatter> customHandleException(Exception ex, WebRequest request){
		LOGGER.error("Exception occured    -----Exception CONTROLLER------- {}", ex.getMessage());
		
		
		
		Date currentDate=new Date();
		ExceptionFormatter formatter=new ExceptionFormatter(currentDate, ex.getMessage(),request.getDescription(false));
		ResponseEntity<ExceptionFormatter> responseEntity;
		if (ex instanceof AmqpException) {
			responseEntity= new ResponseEntity<ExceptionFormatter>(formatter, HttpStatus.SERVICE_UNAVAILABLE);
		}else {
			responseEntity= new ResponseEntity<ExceptionFormatter>(formatter, HttpStatus.NOT_ACCEPTABLE);
		}
		
		
		LOGGER.error("-----Exception CONTROLLER-------  Execution Completed with Exception!");
		return responseEntity;
	}

}
