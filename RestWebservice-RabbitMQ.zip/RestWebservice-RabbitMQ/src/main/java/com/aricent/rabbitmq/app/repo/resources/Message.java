package com.aricent.rabbitmq.app.repo.resources;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="message")
public class Message {
	
	@Id
	private long id;
	
	@Indexed
	private String msgCount;
	
	private String timeStamp;
	
	private String message;

	public Message(long id, String msgCount, String timeStamp, String message) {
		super();
		this.id = id;
		this.msgCount = msgCount;
		this.timeStamp = timeStamp;
		this.message = message;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+id+msgCount+timeStamp+message;
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode()+msgCount.hashCode()+timeStamp.hashCode()+message.hashCode();
	}

	public long getId() {
		return id;
	}

	public String getMsgCount() {
		return msgCount;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public String getMessage() {
		return message;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setMsgCount(String msgCount) {
		this.msgCount = msgCount;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
	
}
