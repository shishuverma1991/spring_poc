package com.aricent.rabbitmq.app.repositories.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Repository;

import com.aricent.rabbitmq.app.repo.resources.Message;
import com.aricent.rabbitmq.app.repositories.spi.IMessageRepository;
import com.aricent.rabbitmq.app.repositories.spi.SequenceGenerator;

@Repository
public class MessageRepositoryImpl{
	
	private Message message;
	
	@Autowired
	private SequenceGenerator<Message> sequenceGenerator;
	
	@Autowired
	private IMessageRepository messageRepository;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageRepositoryImpl.class);
	public void createMessageRepoResource(String msg) {
		
		LOGGER.info("Execution started with value -----Repository------- {}", msg);
		SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yy HH:MM:ss");
		String date = sdf.format(new Date());
		long nextSequence = sequenceGenerator.getNextSequence(Message.class);
		message=new Message(nextSequence,"MSG_"+nextSequence,date, msg);
		messageRepository.save(message);
		
		
		LOGGER.info("Execution completed -----Repository-------successfully");
	}
	
	
	
	
	
}
