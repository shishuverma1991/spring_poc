package com.aricent.mongodb.app.repositories.spi;

public interface SequenceGenerator<T> {

	public long getNextSequence(Class<T> entityClass); 
}
