package com.aricent.mongodb.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWebserviceRabbitMqApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(RestWebserviceRabbitMqApplication.class);
	public static void main(String[] args) {
		
		SpringApplication.run(RestWebserviceRabbitMqApplication.class, args);
		LOGGER.debug("Starting Application....{rabbit-mq-producer}");
		
	}
}
