package com.aricent.mongodb.app.services.impl;

import com.aricent.mongodb.app.repositories.impl.MessageRepositoryImpl;
import com.aricent.mongodb.app.services.spi.CustomService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageService implements CustomService {
	

	
	
	@Autowired
	private MessageRepositoryImpl messageRepositoryImpl;
	
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageService.class);
	
	@Override
	public String produceMessage(String msg){
		
		LOGGER.info("Execution started with value ----- SERVICE-------{}", msg);
		
		
		messageRepositoryImpl.createMessageRepoResource(msg);
		
		LOGGER.info("Execution Completed succesfully! -----SERVICE -------");
		return "Message Sent successfully!";
	}
	
}
