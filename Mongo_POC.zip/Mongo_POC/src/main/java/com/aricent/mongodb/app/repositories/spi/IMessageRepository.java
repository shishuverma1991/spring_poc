package com.aricent.mongodb.app.repositories.spi;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.aricent.mongodb.app.repo.resources.Message;

public interface IMessageRepository extends MongoRepository<Message,Long>{

	

}
