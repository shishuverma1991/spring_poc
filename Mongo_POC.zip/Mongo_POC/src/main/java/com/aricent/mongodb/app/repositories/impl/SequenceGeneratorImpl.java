package com.aricent.mongodb.app.repositories.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Service;

import com.aricent.mongodb.app.repo.resources.Message;
import com.aricent.mongodb.app.repositories.spi.SequenceGenerator;
import com.aricent.mongodb.app.utility.CustomComparotor;
@Service
public class SequenceGeneratorImpl<T> implements SequenceGenerator<T> {
	private T t;
	
	
	@Autowired
	private MongoOperations mongoOperation;
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SequenceGeneratorImpl.class);
	@Override
	public long getNextSequence(Class<T> entityClass) {
		// query to search user
		//Query searchUserQuery = new Query(Criteria.where("msgCount").is("MSG_1"));
		// find the saved user again.
		//Message savedUser = mongoOperation.findOne(searchUserQuery, Message.class);
		LOGGER.info("Execution started with value -----Sequence Repository ------- {}", entityClass);
		List<Message> findAll =(List<Message>) mongoOperation.findAll(entityClass);
		
		findAll.sort(new CustomComparotor<Message>());
		
		//findAll.stream().forEach(item->System.out.println(item.getId()));
		LOGGER.info("Execution Completed Successfully! ----- Sequence respository------- {}", entityClass);
		return findAll.get(0).getId()+1;
	}

}
