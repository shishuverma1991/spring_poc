package com.aricent.mongodb.app.utility;


import java.util.Comparator;

import com.aricent.mongodb.app.repo.resources.Message;

public class CustomComparotor<T> implements Comparator<T> {
	
	

	@Override
	public int compare(T obj1, T obj2) {
		
		int resValue=0;
		if((obj1 instanceof Message) && (obj2 instanceof Message)) {
			Message m1=(Message)obj1;
			
			Message m2=(Message)obj2;
			
			if(m1.getId()>m2.getId()) {
				resValue=-1;
			}
			
			if(m1.getId()<m2.getId()) {
				resValue=1;
			}
			
			
		}
		return resValue;
	}

}
