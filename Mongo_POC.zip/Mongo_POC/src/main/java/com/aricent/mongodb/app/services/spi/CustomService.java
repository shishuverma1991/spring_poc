package com.aricent.mongodb.app.services.spi;


public interface CustomService {

	
	public String produceMessage(String message);
}
