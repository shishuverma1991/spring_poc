package com.aricent.mongodb.app.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aricent.mongodb.app.services.spi.CustomService;


@RestController
@RequestMapping(value="/rabbit-mq-producer")
public class ProducerController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProducerController.class);
	
	@Autowired
	private CustomService messageService;
	
	@PutMapping("/put/message/{message}")
	public ResponseEntity<String> putMessage(@PathVariable(name="message")String message){
		LOGGER.info("Execution started with value -----CONTROLLER------- {}", message);
		String produceMessage = messageService.produceMessage(message);
		LOGGER.info("-----CONTROLLER-------  Execution Completed succesfully!");
		return new ResponseEntity<String>(produceMessage,HttpStatus.OK);
	}
}
