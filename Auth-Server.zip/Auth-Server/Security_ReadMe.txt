This workspace is for the POC of cloud security.....




Eureka-Server {Discovery server to regester and discover services}
Config-Server {For centralized configuration}
Message-Microservice {To handle message for user}
Auth-Server{Authrization Server}
Delegate-Microservice{To call message service internally uses feign and ribbon}
Gateway-server{Zuul gate server}


Security
	• Add dependency{for Spring Cloud Version-Finchley.BUILD-SNAPSHOT}
	<dependency>
		<groupId>org.springframework.cloud</groupId>
		<artifactId>spring-cloud-starter-oauth2</artifactId>
	</dependency>
	
	
	<dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-security</artifactId>
	</dependency>
	• Create basic security layer of authentication to provide authentication manager to Auth-server
		a. Create a simple security config class by extending[WebSecurityConfigurerAdapter and annotating with @enablewebsecurity}
		b. Initialize authentication Manager
		c. Define Url's to be secured other then (/aouth/**){http.authorizeRequests().antMatchers("/oauth/**").permitAll().and().authorizeRequests().anyRequest().authenticated().and().httpBasic();}
		d. Define authentication mode{authentication ----inmemory|jdbc datasource|Userdetail service |custom Authentication Management}
	• Create AUTH server
		a. Create a customauthsecurity layer by extending [AuthorizationServerConfigurerAdapter and annotating with @EnableAuthorizationServer and @configuration]
		b. Autowire AuthenticationManager
		c. Apply security by setting tokenAccess and checkTokenAccess
		d. Configure clientDetail---set grant_type supported,client,client_secret,scopes
		e. Configure authentication manger for endpoints of auth 2.0{/oauth/authorize||/oauth/token||/oauth/checktoken}

	• Using authetication server
	   Grant_type=authorization_code{Autharized by code this is done manually }
			1. Getting code…by manually authorization/denyle
			2. Url to be used :http://localhost:9999/oauth/authorize Type-GET
			3. Params
				{
				response_type=code
				client_id=acme
				redirect_uri=http://google.com
				}
			4. Ex. URL-------http://localhost:9999/oauth/authorize?response_type=code&client_id=acme&redirect_uri=http://google.com
			5. Response you Get:                   ----https://www.google.com/?code=71dWOv
			6. Use the above code to get token i.e grant_type=authorization_code ----http://localhost:9999/oauth/token?code=71dWOv&grant_type=authorization_code&redirect_uri=http://google.com
			7. Please do provide the client id and secret as basic authentication……
		      Response you Get:     
				{
				    "access_token": "21324985-3c96-47a4-a65d-141fbaae6758",
				    "token_type": "bearer",
				    "refresh_token": "65620741-82a9-413b-8223-229de517dcc5",
				    "expires_in": 42960,
				    "scope": "openid"
				}
		 Grant_type=password{we provide the username and password of the authserver with client Id& secret to get token}
				1. Getting code…by manually authorization/denyle
				2. Url to be used :http://localhost:9999/oauth/authorize Type-GET
				3. Params
					{
					grant_type=password
					scope=openid
					username=shishu
					password=password
					}
				4. Ex. URL-------http://localhost:9999/oauth/token?grant_type=password&scope=openid&username=shishu&password=password
				5. Please do provide the client id and secret as basic authentication……
			      Response you Get:     
					{
					    "access_token": "21324985-3c96-47a4-a65d-141fbaae6758",
					    "token_type": "bearer",
					    "refresh_token": "65620741-82a9-413b-8223-229de517dcc5",
					    "expires_in": 42960,
					    "scope": "openid"
					}
		
		
		
		




	
Important Links

https://github.com/bkielczewski/example-spring-boot-security/issues/2--------------------------------for Auth server config
https://docs.spring.io/spring-security/site/docs/4.2.4.RELEASE/apidocs/org/springframework/security/config/annotation/web/builders/HttpSecurity.html---------------------------for basic security config
https://raymondhlee.wordpress.com/tag/enableauthorizationserver/

/oauth/authorize]}" onto public org.springframework.web.servlet.ModelAndView org.springframework.security.oauth2.provider.endpoint.AuthorizationEndpoint.authorize(java.util.Map<java.lang.String, java.lang.Object>,java.util.Map<java.lang.String, java.lang.String>,org.springframework.web.bind.support.SessionStatus,java.security.Principal)


/oauth/authorize],methods=[POST],params=[user_oauth_approval]}" onto public org.springframework.web.servlet.View org.springframework.security.oauth2.provider.endpoint.AuthorizationEndpoint.approveOrDeny(java.util.Map<java.lang.String, java.lang.String>,java.util.Map<java.lang.String, ?>,org.springframework.web.bind.support.SessionStatus,java.security.Principal)


/oauth/token],methods=[GET]}" onto public org.springframework.http.ResponseEntity<org.springframework.security.oauth2.common.OAuth2AccessToken> org.springframework.security.oauth2.provider.endpoint.TokenEndpoint.getAccessToken(java.security.Principal,java.util.Map<java.lang.String, java.lang.String>) throws org.springframework.web.HttpRequestMethodNotSupportedException

/oauth/token],methods=[POST]}" onto public org.springframework.http.ResponseEntity<org.springframework.security.oauth2.common.OAuth2AccessToken> org.springframework.security.oauth2.provider.endpoint.TokenEndpoint.postAccessToken(java.security.Principal,java.util.Map<java.lang.String, java.lang.String>) throws org.springframework.web.HttpRequestMethodNotSupportedException

/oauth/check_token]}" onto public java.util.Map<java.lang.String, ?> org.springframework.security.oauth2.provider.endpoint.CheckTokenEndpoint.checkToken(java.lang.String)
/oauth/confirm_access]}" onto public org.springframework.web.servlet.ModelAndView 

org.springframework.security.oauth2.provider.endpoint.WhitelabelApprovalEndpoint.getAccessConfirmation(java.util.Map<java.lang.String, java.lang.Object>,javax.servlet.http.HttpServletRequest) throws java.lang.Exception

	




