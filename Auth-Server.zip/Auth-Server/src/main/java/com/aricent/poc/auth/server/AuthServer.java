package com.aricent.poc.auth.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableEurekaClient
public class AuthServer {

	private final static Logger logger = LoggerFactory.getLogger(AuthServer.class);

	public static void main(String[] args) {
		logger.info("Spring Boot is starting AuthServer !");
		SpringApplication.run(AuthServer.class, args);
		logger.info("Spring Boot has started AuthServer succesfully!");
	}
}
