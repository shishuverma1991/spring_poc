package com.aricent.poc.auth.server.helper;

import org.springframework.stereotype.Component;

import com.aricent.poc.mscommon.CustomLogger;

@Component
public class MicroserviceLoggerImpl extends CustomLogger {

    public MicroserviceLoggerImpl() {
        super();
    }
    
    
}
